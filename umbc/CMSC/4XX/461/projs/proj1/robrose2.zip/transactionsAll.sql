-- CMSC 461, Spring 2019
-- Robert Rose
-- robrose2

-- 10. A (SQL) transaction for feeding and watering all the pots in a tray. 