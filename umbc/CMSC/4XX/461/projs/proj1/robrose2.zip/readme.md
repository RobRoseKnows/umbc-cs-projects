# How to run

1. Run `createAll.sql`
2. Run `loadAll.sql`
3. Run the python notebook 